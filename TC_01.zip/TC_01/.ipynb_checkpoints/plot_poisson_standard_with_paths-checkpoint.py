#!/usr/bin/env python3
"""
Standard, publication-quality comparison plots for 2D Poisson results.

This script loads the standardized bundle .npz files produced by:
  - KAPI
  - HyperPINN
  - PI-DeepONet

Each bundle must contain (at minimum):
  x          : grid vector (N,) or meshgrid (N,N)
  y          : grid vector (N,) or meshgrid (N,N)
  u_exact    : (n_cases, N, N)
  u_pred     : (n_cases, N, N)
  abs_error  : (n_cases, N, N)

Recommended (for robust alignment/annotation):
  case_names : (n_cases,)
  params     : (n_cases, 3)  where each row is [x0, y0, nu]

Extra keys are allowed and ignored.

Outputs:
  1) Solutions figure: (n_cases x 4)
       [Exact | KAPI | HyperPINN | PI-DeepONet]
  2) Errors figure:    (n_cases x 3)
       [abs_error(KAPI) | abs_error(HyperPINN) | abs_error(PI-DeepONet)]

Saved as both PDF and PNG in the output directory.

-----------------------------------------------------------------------
DEFAULT INPUT PATHS (EDITED as requested):
  /home/vikas/Downloads/META_CASES/TC_01/kapi_bundle.npz
  /home/vikas/Downloads/META_CASES/TC_01/hyperpinn_bundle.npz
  /home/vikas/Downloads/META_CASES/TC_01/pideeponet_bundle.npz
-----------------------------------------------------------------------

Usage:
  python plot_poisson_standard_with_paths.py
  python plot_poisson_standard_with_paths.py --out /path/to/compare_plots --max_cases 4
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt


# ----------------------------- IO helpers ----------------------------- #

def load_bundle(path: Path) -> Dict[str, np.ndarray]:
    """Load an .npz bundle into a plain Python dict."""
    if not path.exists():
        raise FileNotFoundError(f"Bundle not found: {path}")
    data = np.load(path, allow_pickle=True)
    return {k: data[k] for k in data.files}


def ensure_1d_grid(x: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Accept either 1D vectors or 2D mesh grids; return 1D x,y vectors."""
    x = np.asarray(x)
    y = np.asarray(y)

    # If x/y were stored as meshgrids, reduce them to vectors.
    x1 = x[0, :] if x.ndim == 2 else x
    y1 = y[:, 0] if y.ndim == 2 else y

    return np.asarray(x1).ravel(), np.asarray(y1).ravel()


def as_str_list(arr) -> List[str]:
    """Convert a numpy array of strings/objects to a Python list[str]."""
    if arr is None:
        return []
    arr = np.asarray(arr)
    if arr.dtype == object:
        return [str(x) for x in arr.tolist()]
    return [str(x) for x in arr.tolist()]


def intersect_case_order(*case_lists: List[str]) -> List[str]:
    """
    Intersection of case names while preserving the order of the first list.
    If any list is empty (missing case_names), return [] and caller falls back
    to positional alignment.
    """
    if any(len(lst) == 0 for lst in case_lists):
        return []

    ref = case_lists[0]
    common = set(ref)
    for lst in case_lists[1:]:
        common &= set(lst)
    return [c for c in ref if c in common]


def reorder_by_cases(bundle: Dict[str, np.ndarray], target_cases: List[str]) -> Dict[str, np.ndarray]:
    """Reorder per-case arrays in a bundle to match target_cases via case_names."""
    out = dict(bundle)
    src_cases = as_str_list(bundle.get("case_names"))
    idx = {name: i for i, name in enumerate(src_cases)}
    order = [idx[c] for c in target_cases]

    for key in ("u_exact", "u_pred", "abs_error", "params", "case_names"):
        if key in out:
            out[key] = out[key][order]
    return out


# ----------------------------- Plot style ----------------------------- #

def set_pub_rcparams(fontsize: int = 11) -> None:
    """A small set of rcParams suitable for paper figures."""
    mpl.rcParams.update({
        "font.size": fontsize,
        "axes.titlesize": fontsize + 1,
        "axes.labelsize": fontsize,
        "xtick.labelsize": fontsize - 1,
        "ytick.labelsize": fontsize - 1,
        "legend.fontsize": fontsize - 1,
        "figure.titlesize": fontsize + 2,
        "savefig.dpi": 300,
        "pdf.fonttype": 42,  # embed TrueType
        "ps.fonttype": 42,
        "mathtext.fontset": "dejavusans",
        "axes.linewidth": 0.8,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "xtick.minor.width": 0.6,
        "ytick.minor.width": 0.6,
    })


def global_minmax(arrs: List[np.ndarray]) -> Tuple[float, float]:
    """Compute global (vmin, vmax) across a list of arrays."""
    mn = np.inf
    mx = -np.inf
    for a in arrs:
        a = np.asarray(a)
        mn = min(mn, float(np.nanmin(a)))
        mx = max(mx, float(np.nanmax(a)))

    if not np.isfinite(mn) or not np.isfinite(mx):
        return 0.0, 1.0
    if mn == mx:
        mx = mn + 1e-12
    return mn, mx


def format_param_line(params_row: np.ndarray) -> str:
    """Pretty latex string for p = (x0,y0,nu)."""
    try:
        x0, y0, nu = [float(v) for v in params_row]
        return rf"$x_0={x0:.3f},\ y_0={y0:.3f},\ \nu={nu:.4f}$"
    except Exception:
        return ""


# ----------------------------- Core plotting ----------------------------- #

def plot_solution_and_error_panels(
    x: np.ndarray,
    y: np.ndarray,
    case_names: List[str],
    params: Optional[np.ndarray],
    u_exact: np.ndarray,
    u_kapi: np.ndarray,
    u_hyper: np.ndarray,
    u_deep: np.ndarray,
    e_kapi: np.ndarray,
    e_hyper: np.ndarray,
    e_deep: np.ndarray,
    out_dir: Path,
    max_cases: Optional[int] = None,
    cmap_solution: str = "viridis",
    cmap_error: str = "magma",
) -> Tuple[Path, Path, Path, Path]:
    """Create and save the (n_cases×4) solutions plot and (n_cases×3) error plot."""

    out_dir.mkdir(parents=True, exist_ok=True)

    n_cases = int(u_exact.shape[0])
    if max_cases is not None:
        n_cases = min(n_cases, int(max_cases))

        u_exact = u_exact[:n_cases]
        u_kapi = u_kapi[:n_cases]
        u_hyper = u_hyper[:n_cases]
        u_deep = u_deep[:n_cases]

        e_kapi = e_kapi[:n_cases]
        e_hyper = e_hyper[:n_cases]
        e_deep = e_deep[:n_cases]

        case_names = case_names[:n_cases]
        if params is not None:
            params = params[:n_cases]

    # Global shared scales for honest comparison
    sol_vmin, sol_vmax = global_minmax([u_exact, u_kapi, u_hyper, u_deep])
    err_vmin, err_vmax = 0.0, global_minmax([e_kapi, e_hyper, e_deep])[1]

    extent = [float(x.min()), float(x.max()), float(y.min()), float(y.max())]

    # ---------------- Figure 1: Solutions (n_cases x 4) ----------------
    fig1, axes1 = plt.subplots(
        n_cases, 4,
        figsize=(3.2 * 4, 3.0 * n_cases),
        constrained_layout=True,
    )
    if n_cases == 1:
        axes1 = np.expand_dims(axes1, axis=0)

    col_titles = ["Exact (FDM)", "KAPI", "HyperPINN", "PI-DeepONet"]
    cols = [u_exact, u_kapi, u_hyper, u_deep]

    last_im = None
    for r in range(n_cases):
        for c in range(4):
            ax = axes1[r, c]
            last_im = ax.imshow(
                cols[c][r],
                origin="lower",
                extent=extent,
                vmin=sol_vmin, vmax=sol_vmax,
                cmap=cmap_solution,
                interpolation="nearest",
                aspect="equal",
            )
            ax.set_xticks([])
            ax.set_yticks([])

            if r == 0:
                ax.set_title(col_titles[c], pad=8)

            if c == 0:
                label = case_names[r] if r < len(case_names) else f"case {r:02d}"
                if params is not None:
                    pline = format_param_line(params[r])
                    if pline:
                        label = f"{label}\n{pline}"
                ax.set_ylabel(label, rotation=0, labelpad=55, va="center")

    cbar1 = fig1.colorbar(last_im, ax=axes1, shrink=0.92, pad=0.01)
    cbar1.set_label(r"$u(x,y)$")
    fig1.suptitle("2D Poisson: Exact vs Learned Solutions", y=1.02)

    sol_pdf = out_dir / "poisson_compare_solutions_4cols.pdf"
    sol_png = out_dir / "poisson_compare_solutions_4cols.png"
    fig1.savefig(sol_pdf, bbox_inches="tight")
    fig1.savefig(sol_png, bbox_inches="tight")
    plt.close(fig1)

    # ---------------- Figure 2: Errors (n_cases x 3) ----------------
    fig2, axes2 = plt.subplots(
        n_cases, 3,
        figsize=(3.2 * 3, 3.0 * n_cases),
        constrained_layout=True,
    )
    if n_cases == 1:
        axes2 = np.expand_dims(axes2, axis=0)

    col_titles2 = [
        r"$|u_{\mathrm{KAPI}}-u_{\mathrm{exact}}|$",
        r"$|u_{\mathrm{HyperPINN}}-u_{\mathrm{exact}}|$",
        r"$|u_{\mathrm{DeepONet}}-u_{\mathrm{exact}}|$",
    ]
    err_cols = [e_kapi, e_hyper, e_deep]

    last_im2 = None
    for r in range(n_cases):
        for c in range(3):
            ax = axes2[r, c]
            last_im2 = ax.imshow(
                err_cols[c][r],
                origin="lower",
                extent=extent,
                vmin=err_vmin, vmax=err_vmax,
                cmap=cmap_error,
                interpolation="nearest",
                aspect="equal",
            )
            ax.set_xticks([])
            ax.set_yticks([])

            if r == 0:
                ax.set_title(col_titles2[c], pad=8)

            if c == 0:
                label = case_names[r] if r < len(case_names) else f"case {r:02d}"
                ax.set_ylabel(label, rotation=0, labelpad=40, va="center")

    cbar2 = fig2.colorbar(last_im2, ax=axes2, shrink=0.92, pad=0.01)
    cbar2.set_label(r"absolute error")
    fig2.suptitle("2D Poisson: Absolute Error Maps", y=1.02)

    err_pdf = out_dir / "poisson_compare_errors_3cols.pdf"
    err_png = out_dir / "poisson_compare_errors_3cols.png"
    fig2.savefig(err_pdf, bbox_inches="tight")
    fig2.savefig(err_png, bbox_inches="tight")
    plt.close(fig2)

    return sol_pdf, sol_png, err_pdf, err_png


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create standard publication-quality Poisson comparison plots from standardized bundles (u_exact, u_pred, abs_error)."
    )

    # --------- DEFAULTS UPDATED TO YOUR ACTUAL LOCATIONS ---------
    parser.add_argument(
        "--kapi",
        type=str,
        default="/home/vikas/Downloads/META_CASES/TC_01/kapi_bundle.npz",
        help="Path to KAPI bundle .npz",
    )
    parser.add_argument(
        "--hyper",
        type=str,
        default="/home/vikas/Downloads/META_CASES/TC_01/hyperpinn_bundle.npz",
        help="Path to HyperPINN bundle .npz",
    )
    parser.add_argument(
        "--deeponet",
        type=str,
        default="/home/vikas/Downloads/META_CASES/TC_01/pideeponet_bundle.npz",
        help="Path to PI-DeepONet bundle .npz",
    )
    # ------------------------------------------------------------

    parser.add_argument(
        "--out",
        type=str,
        default="/home/vikas/Downloads/META_CASES/TC_01/compare_plots",
        help="Output directory for figures",
    )
    parser.add_argument(
        "--max_cases",
        type=int,
        default=4,
        help="Plot only the first N cases (after alignment). Use --max_cases 999 or remove flag to plot all.",
    )
    parser.add_argument("--fontsize", type=int, default=11, help="Base font size")
    parser.add_argument("--cmap_solution", type=str, default="viridis", help="Colormap for solution fields")
    parser.add_argument("--cmap_error", type=str, default="magma", help="Colormap for error fields")
    args = parser.parse_args()

    set_pub_rcparams(fontsize=args.fontsize)

    kapi = load_bundle(Path(args.kapi))
    hyp = load_bundle(Path(args.hyper))
    deep = load_bundle(Path(args.deeponet))

    # Required keys (minimal standard)
    req = ("x", "y", "u_exact", "u_pred", "abs_error")
    for name, b in [("KAPI", kapi), ("HyperPINN", hyp), ("PI-DeepONet", deep)]:
        missing = [k for k in req if k not in b]
        if missing:
            raise KeyError(f"{name} bundle missing required keys: {missing}")

    # Grid (use KAPI as reference)
    x, y = ensure_1d_grid(kapi["x"], kapi["y"])

    # Align by common case_names if present, else positional fallback
    cases_k = as_str_list(kapi.get("case_names"))
    cases_h = as_str_list(hyp.get("case_names"))
    cases_d = as_str_list(deep.get("case_names"))
    common_cases = intersect_case_order(cases_k, cases_h, cases_d)

    if common_cases:
        kapi_a = reorder_by_cases(kapi, common_cases)
        hyp_a = reorder_by_cases(hyp, common_cases)
        deep_a = reorder_by_cases(deep, common_cases)
        case_names = common_cases

        # Prefer params from KAPI; otherwise take from others if available
        params = kapi_a.get("params", None)
        if params is None:
            params = hyp_a.get("params", None)
        if params is None:
            params = deep_a.get("params", None)
    else:
        # Fallback to minimum common length
        n = min(
            kapi["u_pred"].shape[0],
            hyp["u_pred"].shape[0],
            deep["u_pred"].shape[0],
            kapi["u_exact"].shape[0],
        )
        kapi_a, hyp_a, deep_a = kapi, hyp, deep
        case_names = cases_k[:n] if cases_k else [f"case {i:02d}" for i in range(n)]
        params = kapi.get("params", None)

        # Truncate per-case arrays for safety
        for b in (kapi_a, hyp_a, deep_a):
            for key in ("u_exact", "u_pred", "abs_error", "params", "case_names"):
                if key in b and np.asarray(b[key]).ndim >= 1 and np.asarray(b[key]).shape[0] >= n:
                    b[key] = b[key][:n]

    # Use exact from KAPI (standardized by construction)
    u_exact = np.asarray(kapi_a["u_exact"])
    u_kapi  = np.asarray(kapi_a["u_pred"])
    u_hyper = np.asarray(hyp_a["u_pred"])
    u_deep  = np.asarray(deep_a["u_pred"])

    # Use abs_error directly from each bundle (standard requirement)
    e_kapi  = np.asarray(kapi_a["abs_error"])
    e_hyper = np.asarray(hyp_a["abs_error"])
    e_deep  = np.asarray(deep_a["abs_error"])

    out_dir = Path(args.out)
    sol_pdf, sol_png, err_pdf, err_png = plot_solution_and_error_panels(
        x=x,
        y=y,
        case_names=case_names,
        params=params,
        u_exact=u_exact,
        u_kapi=u_kapi,
        u_hyper=u_hyper,
        u_deep=u_deep,
        e_kapi=e_kapi,
        e_hyper=e_hyper,
        e_deep=e_deep,
        out_dir=out_dir,
        max_cases=args.max_cases,
        cmap_solution=args.cmap_solution,
        cmap_error=args.cmap_error,
    )

    print("Saved:")
    print(f"  {sol_pdf}")
    print(f"  {sol_png}")
    print(f"  {err_pdf}")
    print(f"  {err_png}")


if __name__ == "__main__":
    main()
